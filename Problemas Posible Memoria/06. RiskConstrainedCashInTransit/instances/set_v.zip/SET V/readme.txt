File name
Number of nodes 

Instance Structure
Number of nodes
Risk Threshold
Demand Vector
Node Coordinates [x y]


