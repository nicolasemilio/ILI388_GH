File name
Number of nodes - Standard Deviation of the Demand* - Risk Level


Instance Structure
Number of nodes
Risk Threshold
Demand Vector
Node Coordinates [x y]


*Note on the nomenclature used for the Standard Deviation of the Demand  
1 stands for standard deviation of the demand =1
3 stands for standard deviation of the demand =4
5 stands for standard deviation of the demand =16
7 stands for standard deviation of the demand =64
